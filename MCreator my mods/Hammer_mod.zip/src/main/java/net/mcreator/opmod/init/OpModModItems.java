
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.opmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.Item;

import net.mcreator.opmod.item.WoodenhammerItem;
import net.mcreator.opmod.item.StonehammerItem;
import net.mcreator.opmod.item.NetheritehammerItem;
import net.mcreator.opmod.item.IronhammerItem;
import net.mcreator.opmod.item.GoldhammerItem;
import net.mcreator.opmod.item.DiamondhammerItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OpModModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item DIAMONDHAMMER = register(new DiamondhammerItem());
	public static final Item NETHERITEHAMMER = register(new NetheritehammerItem());
	public static final Item GOLDHAMMER = register(new GoldhammerItem());
	public static final Item IRONHAMMER = register(new IronhammerItem());
	public static final Item STONEHAMMER = register(new StonehammerItem());
	public static final Item WOODENHAMMER = register(new WoodenhammerItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
