
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.opmod.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class OpModModTabs {
	public static CreativeModeTab TAB_MOREFOOD;

	public static void load() {
		TAB_MOREFOOD = new CreativeModeTab("tabmorefood") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(OpModModItems.BURGER);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
