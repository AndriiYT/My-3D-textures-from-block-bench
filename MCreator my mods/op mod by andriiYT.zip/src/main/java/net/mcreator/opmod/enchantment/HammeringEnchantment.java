
package net.mcreator.opmod.enchantment;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.opmod.init.OpModModEnchantments;

public class HammeringEnchantment extends Enchantment {
	public HammeringEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.RARE, EnchantmentCategory.DIGGER, slots);
	}

	@Override
	protected boolean checkCompatibility(Enchantment ench) {
		if (ench == OpModModEnchantments.AUTOSMELT)
			return true;
		if (ench == Enchantments.BLOCK_EFFICIENCY)
			return true;
		if (ench == Enchantments.UNBREAKING)
			return true;
		return false;
	}
}
