package net.mcreator.opmod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.opmod.init.OpModModMobEffects;
import net.mcreator.opmod.init.OpModModItems;

public class EffectonlapizarmorProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY)
				.getItem() == OpModModItems.LAPIZ_ARMOR_BOOTS
				&& (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY)
						.getItem() == OpModModItems.LAPIZ_ARMOR_LEGGINGS
				&& (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY)
						.getItem() == OpModModItems.LAPIZ_ARMOR_CHESTPLATE
				&& (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY)
						.getItem() == OpModModItems.LAPIZ_ARMOR_HELMET) {
			if (entity instanceof LivingEntity _entity)
				_entity.addEffect(new MobEffectInstance(OpModModMobEffects.FLY, 1000, 1, (false), (false)));
		}
	}
}
