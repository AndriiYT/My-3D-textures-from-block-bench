package net.mcreator.opmod.procedures;

import net.minecraftforge.common.TierSortingRegistry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class ZxZblockminertoolProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getDirection()) == Direction.NORTH || (entity.getDirection()) == Direction.SOUTH) {
			if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0))))
					.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
						public int getHarvestLevel(Block _bl) {
							return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel).findFirst()
									.orElse(0);
						}
					}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0))).getBlock()) < 3) {
				if (world instanceof Level) {
					Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0))), (Level) world,
							new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0)));
					world.destroyBlock(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0)), false);
				}
				((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
						(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue() + 1));
				if ((world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z + 0))))
						.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
							public int getHarvestLevel(Block _bl) {
								return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel)
										.findFirst().orElse(0);
							}
						}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z + 0))).getBlock()) < 3) {
					if (world instanceof Level) {
						Block.dropResources(world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z + 0))), (Level) world,
								new BlockPos((int) (x + 1), (int) (y + 1), (int) (z + 0)));
						world.destroyBlock(new BlockPos((int) (x + 1), (int) (y + 1), (int) (z + 0)), false);
					}
					((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
							(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue() + 1));
					if ((world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z + 0))))
							.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
								public int getHarvestLevel(Block _bl) {
									return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel)
											.findFirst().orElse(0);
								}
							}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z + 0))).getBlock()) < 3) {
						if (world instanceof Level) {
							Block.dropResources(world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z + 0))), (Level) world,
									new BlockPos((int) (x - 1), (int) (y + 1), (int) (z + 0)));
							world.destroyBlock(new BlockPos((int) (x - 1), (int) (y + 1), (int) (z + 0)), false);
						}
						((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
								(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue()
										+ 1));
						if ((world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 0), (int) (z + 0))))
								.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
									public int getHarvestLevel(Block _bl) {
										return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel)
												.findFirst().orElse(0);
									}
								}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 0), (int) (z + 0))).getBlock()) < 3) {
							if (world instanceof Level) {
								Block.dropResources(world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 0), (int) (z + 0))), (Level) world,
										new BlockPos((int) (x + 1), (int) (y + 0), (int) (z + 0)));
								world.destroyBlock(new BlockPos((int) (x + 1), (int) (y + 0), (int) (z + 0)), false);
							}
							((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
									(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue()
											+ 1));
							if ((world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 0), (int) (z + 0))))
									.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
										public int getHarvestLevel(Block _bl) {
											return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
													.map(Tier::getLevel).findFirst().orElse(0);
										}
									}.getHarvestLevel(
											world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 0), (int) (z + 0))).getBlock()) < 3) {
								if (world instanceof Level) {
									Block.dropResources(world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 0), (int) (z + 0))), (Level) world,
											new BlockPos((int) (x - 1), (int) (y + 0), (int) (z + 0)));
									world.destroyBlock(new BlockPos((int) (x - 1), (int) (y + 0), (int) (z + 0)), false);
								}
								((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
										(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
												.getDamageValue() + 1));
								if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0))))
										.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
											public int getHarvestLevel(Block _bl) {
												return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
														.map(Tier::getLevel).findFirst().orElse(0);
											}
										}.getHarvestLevel(
												world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0))).getBlock()) < 3) {
									if (world instanceof Level) {
										Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0))),
												(Level) world, new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0)));
										world.destroyBlock(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0)), false);
									}
									((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
											(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
													.getDamageValue() + 1));
									if ((world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z + 0))))
											.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
												public int getHarvestLevel(Block _bl) {
													return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
															.map(Tier::getLevel).findFirst().orElse(0);
												}
											}.getHarvestLevel(
													world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z + 0))).getBlock()) < 3) {
										if (world instanceof Level) {
											Block.dropResources(world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z + 0))),
													(Level) world, new BlockPos((int) (x + 1), (int) (y - 1), (int) (z + 0)));
											world.destroyBlock(new BlockPos((int) (x + 1), (int) (y - 1), (int) (z + 0)), false);
										}
										((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
												(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
														.getDamageValue() + 1));
										if ((world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z + 0))))
												.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
													public int getHarvestLevel(Block _bl) {
														return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
																.map(Tier::getLevel).findFirst().orElse(0);
													}
												}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z + 0)))
														.getBlock()) < 3) {
											if (world instanceof Level) {
												Block.dropResources(world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z + 0))),
														(Level) world, new BlockPos((int) (x - 1), (int) (y - 1), (int) (z + 0)));
												world.destroyBlock(new BlockPos((int) (x - 1), (int) (y - 1), (int) (z + 0)), false);
											}
											((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
													(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
															.getDamageValue() + 1));
										}
									}
								}
							}
						}
					}
				}
			}
		} else if ((entity.getDirection()) == Direction.WEST || (entity.getDirection()) == Direction.EAST) {
			if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0))))
					.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
						public int getHarvestLevel(Block _bl) {
							return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel).findFirst()
									.orElse(0);
						}
					}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0))).getBlock()) < 3) {
				if (world instanceof Level) {
					Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0))), (Level) world,
							new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0)));
					world.destroyBlock(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 0)), false);
				}
				((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
						(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue() + 1));
				if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 1))))
						.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
							public int getHarvestLevel(Block _bl) {
								return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel)
										.findFirst().orElse(0);
							}
						}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 1))).getBlock()) < 3) {
					if (world instanceof Level) {
						Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 1))), (Level) world,
								new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 1)));
						world.destroyBlock(new BlockPos((int) (x + 0), (int) (y + 1), (int) (z + 1)), false);
					}
					((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
							(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue() + 1));
					if ((world.getBlockState(new BlockPos((int) (x - 0), (int) (y + 1), (int) (z - 1))))
							.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
								public int getHarvestLevel(Block _bl) {
									return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel)
											.findFirst().orElse(0);
								}
							}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x - 0), (int) (y + 1), (int) (z - 1))).getBlock()) < 3) {
						if (world instanceof Level) {
							Block.dropResources(world.getBlockState(new BlockPos((int) (x - 0), (int) (y + 1), (int) (z - 1))), (Level) world,
									new BlockPos((int) (x - 0), (int) (y + 1), (int) (z - 1)));
							world.destroyBlock(new BlockPos((int) (x - 0), (int) (y + 1), (int) (z - 1)), false);
						}
						((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
								(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue()
										+ 1));
						if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 0), (int) (z + 1))))
								.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
									public int getHarvestLevel(Block _bl) {
										return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl)).map(Tier::getLevel)
												.findFirst().orElse(0);
									}
								}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 0), (int) (z + 1))).getBlock()) < 3) {
							if (world instanceof Level) {
								Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y + 0), (int) (z + 1))), (Level) world,
										new BlockPos((int) (x + 0), (int) (y + 0), (int) (z + 1)));
								world.destroyBlock(new BlockPos((int) (x + 0), (int) (y + 0), (int) (z + 1)), false);
							}
							((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
									(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).getDamageValue()
											+ 1));
							if ((world.getBlockState(new BlockPos((int) (x - 0), (int) (y + 0), (int) (z - 1))))
									.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
										public int getHarvestLevel(Block _bl) {
											return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
													.map(Tier::getLevel).findFirst().orElse(0);
										}
									}.getHarvestLevel(
											world.getBlockState(new BlockPos((int) (x - 0), (int) (y + 0), (int) (z - 1))).getBlock()) < 3) {
								if (world instanceof Level) {
									Block.dropResources(world.getBlockState(new BlockPos((int) (x - 0), (int) (y + 0), (int) (z - 1))), (Level) world,
											new BlockPos((int) (x - 0), (int) (y + 0), (int) (z - 1)));
									world.destroyBlock(new BlockPos((int) (x - 0), (int) (y + 0), (int) (z - 1)), false);
								}
								((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
										(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
												.getDamageValue() + 1));
								if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0))))
										.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
											public int getHarvestLevel(Block _bl) {
												return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
														.map(Tier::getLevel).findFirst().orElse(0);
											}
										}.getHarvestLevel(
												world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0))).getBlock()) < 3) {
									if (world instanceof Level) {
										Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0))),
												(Level) world, new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0)));
										world.destroyBlock(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 0)), false);
									}
									((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
											(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
													.getDamageValue() + 1));
									if ((world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 1))))
											.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
												public int getHarvestLevel(Block _bl) {
													return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
															.map(Tier::getLevel).findFirst().orElse(0);
												}
											}.getHarvestLevel(
													world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 1))).getBlock()) < 3) {
										if (world instanceof Level) {
											Block.dropResources(world.getBlockState(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 1))),
													(Level) world, new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 1)));
											world.destroyBlock(new BlockPos((int) (x + 0), (int) (y - 1), (int) (z + 1)), false);
										}
										((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
												(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
														.getDamageValue() + 1));
										if ((world.getBlockState(new BlockPos((int) (x - 0), (int) (y - 1), (int) (z - 1))))
												.getMaterial() == net.minecraft.world.level.material.Material.STONE && new Object() {
													public int getHarvestLevel(Block _bl) {
														return TierSortingRegistry.getSortedTiers().stream().filter(t -> t.getTag().contains(_bl))
																.map(Tier::getLevel).findFirst().orElse(0);
													}
												}.getHarvestLevel(world.getBlockState(new BlockPos((int) (x - 0), (int) (y - 1), (int) (z - 1)))
														.getBlock()) < 3) {
											if (world instanceof Level) {
												Block.dropResources(world.getBlockState(new BlockPos((int) (x - 0), (int) (y - 1), (int) (z - 1))),
														(Level) world, new BlockPos((int) (x - 0), (int) (y - 1), (int) (z - 1)));
												world.destroyBlock(new BlockPos((int) (x - 0), (int) (y - 1), (int) (z - 1)), false);
											}
											((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)).setDamageValue(
													(int) (((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY))
															.getDamageValue() + 1));
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
