
package net.mcreator.opmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

import net.mcreator.opmod.init.OpModModTabs;

public class CutedcucumberItem extends Item {
	public CutedcucumberItem() {
		super(new Item.Properties().tab(OpModModTabs.TAB_MOREFOOD).stacksTo(64).rarity(Rarity.COMMON)
				.food((new FoodProperties.Builder()).nutrition(6).saturationMod(0.3f)

						.build()));
		setRegistryName("cutedcucumber");
	}

	@Override
	public int getUseDuration(ItemStack stack) {
		return 40;
	}
}
