
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.opmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.opmod.item.WoodenhammerItem;
import net.mcreator.opmod.item.Unreloadbarret50Item;
import net.mcreator.opmod.item.TomatoItem;
import net.mcreator.opmod.item.StonehammerItem;
import net.mcreator.opmod.item.RedstoneArmorItem;
import net.mcreator.opmod.item.PizzaItem;
import net.mcreator.opmod.item.Ninja_oreItem;
import net.mcreator.opmod.item.NinjaItem;
import net.mcreator.opmod.item.NetheritehammerItem;
import net.mcreator.opmod.item.LapizArmorItem;
import net.mcreator.opmod.item.KetchupItem;
import net.mcreator.opmod.item.KatanaItem;
import net.mcreator.opmod.item.IronhammerItem;
import net.mcreator.opmod.item.GoldhammerItem;
import net.mcreator.opmod.item.DiamondhammerItem;
import net.mcreator.opmod.item.CutedcucumberItem;
import net.mcreator.opmod.item.CucumberItem;
import net.mcreator.opmod.item.CheeseItem;
import net.mcreator.opmod.item.BurgerItem;
import net.mcreator.opmod.item.BedrockpickaxeItem;
import net.mcreator.opmod.item.Barret50Item;
import net.mcreator.opmod.item.AmmoforfastgunsItem;
import net.mcreator.opmod.item.AmmoItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OpModModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item DIAMONDHAMMER = register(new DiamondhammerItem());
	public static final Item NETHERITEHAMMER = register(new NetheritehammerItem());
	public static final Item GOLDHAMMER = register(new GoldhammerItem());
	public static final Item IRONHAMMER = register(new IronhammerItem());
	public static final Item STONEHAMMER = register(new StonehammerItem());
	public static final Item WOODENHAMMER = register(new WoodenhammerItem());
	public static final Item LANDMINE = register(OpModModBlocks.LANDMINE, CreativeModeTab.TAB_REDSTONE);
	public static final Item LANDMINEOFF = register(OpModModBlocks.LANDMINEOFF, null);
	public static final Item WARDROBE = register(OpModModBlocks.WARDROBE, CreativeModeTab.TAB_DECORATIONS);
	public static final Item SHILEDFORWINDOWS = register(OpModModBlocks.SHILEDFORWINDOWS, CreativeModeTab.TAB_DECORATIONS);
	public static final Item MODERNSHELVES = register(OpModModBlocks.MODERNSHELVES, CreativeModeTab.TAB_DECORATIONS);
	public static final Item CURTAINS = register(OpModModBlocks.CURTAINS, CreativeModeTab.TAB_DECORATIONS);
	public static final Item REDSTONE_ARMOR_HELMET = register(new RedstoneArmorItem.Helmet());
	public static final Item REDSTONE_ARMOR_CHESTPLATE = register(new RedstoneArmorItem.Chestplate());
	public static final Item REDSTONE_ARMOR_LEGGINGS = register(new RedstoneArmorItem.Leggings());
	public static final Item REDSTONE_ARMOR_BOOTS = register(new RedstoneArmorItem.Boots());
	public static final Item LAPIZ_ARMOR_HELMET = register(new LapizArmorItem.Helmet());
	public static final Item LAPIZ_ARMOR_CHESTPLATE = register(new LapizArmorItem.Chestplate());
	public static final Item LAPIZ_ARMOR_LEGGINGS = register(new LapizArmorItem.Leggings());
	public static final Item LAPIZ_ARMOR_BOOTS = register(new LapizArmorItem.Boots());
	public static final Item AMMOFORFASTGUNS = register(new AmmoforfastgunsItem());
	public static final Item BARRET_50 = register(new Barret50Item());
	public static final Item AMMO = register(new AmmoItem());
	public static final Item UNRELOADBARRET_50 = register(new Unreloadbarret50Item());
	public static final Item TOMATO = register(new TomatoItem());
	public static final Item TOMATOSEEDS = register(OpModModBlocks.TOMATOSEEDS, OpModModTabs.TAB_MOREFOOD);
	public static final Item KETCHUP = register(new KetchupItem());
	public static final Item CUTEDCUCUMBER = register(new CutedcucumberItem());
	public static final Item CUCUMBER = register(new CucumberItem());
	public static final Item CUCUMBERSEEDS = register(OpModModBlocks.CUCUMBERSEEDS, OpModModTabs.TAB_MOREFOOD);
	public static final Item CHEESE = register(new CheeseItem());
	public static final Item PIZZA = register(new PizzaItem());
	public static final Item BURGER = register(new BurgerItem());
	public static final Item NINJA_HELMET = register(new NinjaItem.Helmet());
	public static final Item NINJA_CHESTPLATE = register(new NinjaItem.Chestplate());
	public static final Item NINJA_LEGGINGS = register(new NinjaItem.Leggings());
	public static final Item NINJA_BOOTS = register(new NinjaItem.Boots());
	public static final Item HUGECRAFTINGTABBLE = register(OpModModBlocks.HUGECRAFTINGTABBLE, CreativeModeTab.TAB_DECORATIONS);
	public static final Item KATANA = register(new KatanaItem());
	public static final Item TV = register(OpModModBlocks.TV, CreativeModeTab.TAB_DECORATIONS);
	public static final Item NINJA_ORE = register(new Ninja_oreItem());
	public static final Item NINJA_ORE_ORE = register(OpModModBlocks.NINJA_ORE_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item NINJA_ORE_BLOCK = register(OpModModBlocks.NINJA_ORE_BLOCK, OpModModTabs.TAB_MOREFOOD);
	public static final Item GHOSTGRASS = register(OpModModBlocks.GHOSTGRASS, CreativeModeTab.TAB_DECORATIONS);
	public static final Item BEDROCKPICKAXE = register(new BedrockpickaxeItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
