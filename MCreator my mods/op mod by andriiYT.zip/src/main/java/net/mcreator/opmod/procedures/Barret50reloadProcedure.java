package net.mcreator.opmod.procedures;

public class Barret50reloadProcedure {
	public static void execute() {
	}
}
