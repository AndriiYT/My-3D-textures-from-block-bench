
package net.mcreator.opmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class AmmoItem extends Item {
	public AmmoItem() {
		super(new Item.Properties().tab(null).stacksTo(0).rarity(Rarity.COMMON));
		setRegistryName("ammo");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
