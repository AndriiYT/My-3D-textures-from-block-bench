
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.opmod.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.opmod.block.WardrobeBlock;
import net.mcreator.opmod.block.TvBlock;
import net.mcreator.opmod.block.TomatoseedsBlock;
import net.mcreator.opmod.block.ShiledforwindowsBlock;
import net.mcreator.opmod.block.Ninja_oreOreBlock;
import net.mcreator.opmod.block.Ninja_oreBlockBlock;
import net.mcreator.opmod.block.ModernshelvesBlock;
import net.mcreator.opmod.block.LandmineoffBlock;
import net.mcreator.opmod.block.LandmineBlock;
import net.mcreator.opmod.block.HugecraftingtabbleBlock;
import net.mcreator.opmod.block.GhostgrassBlock;
import net.mcreator.opmod.block.CurtainsBlock;
import net.mcreator.opmod.block.CucumberseedsBlock;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OpModModBlocks {
	private static final List<Block> REGISTRY = new ArrayList<>();
	public static final Block LANDMINE = register(new LandmineBlock());
	public static final Block LANDMINEOFF = register(new LandmineoffBlock());
	public static final Block WARDROBE = register(new WardrobeBlock());
	public static final Block SHILEDFORWINDOWS = register(new ShiledforwindowsBlock());
	public static final Block MODERNSHELVES = register(new ModernshelvesBlock());
	public static final Block CURTAINS = register(new CurtainsBlock());
	public static final Block TOMATOSEEDS = register(new TomatoseedsBlock());
	public static final Block CUCUMBERSEEDS = register(new CucumberseedsBlock());
	public static final Block HUGECRAFTINGTABBLE = register(new HugecraftingtabbleBlock());
	public static final Block TV = register(new TvBlock());
	public static final Block NINJA_ORE_ORE = register(new Ninja_oreOreBlock());
	public static final Block NINJA_ORE_BLOCK = register(new Ninja_oreBlockBlock());
	public static final Block GHOSTGRASS = register(new GhostgrassBlock());

	private static Block register(Block block) {
		REGISTRY.add(block);
		return block;
	}

	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Block[0]));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			LandmineBlock.registerRenderLayer();
			LandmineoffBlock.registerRenderLayer();
			WardrobeBlock.registerRenderLayer();
			ShiledforwindowsBlock.registerRenderLayer();
			ModernshelvesBlock.registerRenderLayer();
			CurtainsBlock.registerRenderLayer();
			TomatoseedsBlock.registerRenderLayer();
			CucumberseedsBlock.registerRenderLayer();
			HugecraftingtabbleBlock.registerRenderLayer();
			TvBlock.registerRenderLayer();
		}
	}
}
